<?php

// CSV読み込み関数.
function readDataCSV($filename) {
    if (!file_exists($filename)) {
        die("エラー: ファイルが見つかりません。");
    }

    $file = fopen($filename, "r");

    // 最初の5行をスキップ.
    for ($i = 0; $i < 5; $i++) {
        fgetcsv($file);
    }
    $data = [];
    while (($row = fgets($file)) !== false) {
        $row=mb_convert_encoding($row, "UTF-8", "SJIS-win");
        $row = str_replace(array('"', "\r", "\n"), '', $row) . " ";

        $linedata = array_map('trim', explode(',', $row));//要素をコンマで区切り、各要素の前後の空白を削除.

        $data[] = [ //各列のデータを格納。何もないときはそれぞれ空か0を代入する.
            "number" => (int)($linedata[0] ?? 0),
            "CourseCategory" => $linedata[1] ?? "",
            "CourseSubcategory" => $linedata[2] ?? "",
            "CourseDivision" => $linedata[3] ?? "",
            "CourseName" => $linedata[4] ?? "",
            "EnglishCourse" => $linedata[5] ?? "",
            "Credits" => (int)($linedata[6] ?? 0),
            "YearAcquired" => $linedata[7] ?? "",
            "SemesterAcquired" => $linedata[8] ?? "",
            "Grade" => (int)($linedata[9]?? 0),
            "GradeDescription" => $linedata[10] ?? "",
            "PassFail" => $linedata[11] ?? ""
        ];
    }
    fclose($file);
    return $data; //格納したデータを返す.この時のdata配列は、data[2]["number"]=0;などのような二次元配列になっている.
    // data配列の取り出し方の一例 :  echo $data[0]["number"] . $data[1]["CourseCategory"] ."<br>";  などのようにして要素を取り出す.デバック時に試してほしい.

}


// 進級要件 CSV を読み込む関数.
function readRequiredCreditsCSV($filename) {
    $requiredCredits = [];

    //ファイルを読み込めたかチェック.
    if (!file_exists($filename)) {
        die("エラー: ファイルが見つかりません。");
    }

    $file = fopen($filename, "r");
    fgetcsv($file); // ヘッダーをスキップ.

    //読み込めない行が出るまで読み込み、そのデータをrequireCredits配列に格納する.つまり,csvファイルの途中に空の行があった場合はバグが発生するので、csvファイル作成時は気を付けてほしい.
    while (($row = fgets($file)) !== false) 
    {
        $linedata = array_map('trim', explode(',', $row)); //要素をコンマで区切り、各要素の前後の空白を削除.
        $requiredCredits[$linedata[0]] = (int)$linedata[1];//データをc++でいうところのmap<string,int>関数のように格納.
    }

    fclose($file);
    return $requiredCredits;
}

// ファイルアップロード & 進級判定
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["score_csv"])) { //postメソッドで、そのファイル名にscore_scvが含まれているかチェック.これはhtmlが受け取るcsvを指している.
    $fileTmpPath = $_FILES["score_csv"]["tmp_name"]; //$fileTmpPathに一時的にファイルを保存.


    /*
    $fileTmpPathではファイルは一時的にしか保存されないため、ファイルを保存したいならmove_uploaded_file()を使用する必要がある.
    以下はファイルを保存したいときに使用するコード.データを保存したいならデータベースを使えばいいのでデバック用である.

    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
    }

    $uploadedFile = $uploadDir . basename($_FILES["score_csv"]["name"]);
    if (!move_uploaded_file($fileTmpPath, $uploadedFile)) {
        die("エラー: ファイルのアップロードに失敗しました。");
    }
    */

    //各csvを読み込む.
    $MyScore = readDataCSV($fileTmpPath);
    $Move_To_Yonezawa = readRequiredCreditsCSV("Move_to_Yonezawa.csv");
    $Graduation_Research=readRequiredCreditsCSV("Graduation_Research_Requirements.csv");
    $Graduation_Requirements=readRequiredCreditsCSV("Graduation_Requirements.csv");

    //それぞれの条件を計算.なお、keisan()はbool関数である.
    echo"<h3>✅ 米沢進級条件を満たしているか計算します</h3>";
    $Is_Move_To_Yonezawa = keisan($MyScore, $Move_To_Yonezawa);
    echo"<h3>✅ 卒研着手条件を満たしているか計算します</h3>";
    $Is_result_Research=keisan($MyScore,$Graduation_Research);
    echo"<h3>卒業研究条件を満たしているか計算します</h3>";
    $Is_result_Graduation=keisan($MyScore,$Graduation_Requirements);

    //進級条件を出力.
    echo "<h2>進級判定結果</h2>";
    if ($Is_Move_To_Yonezawa) {
        echo "<p style='color:green;'>✅ 米沢進級に問題はありません！</p>";
    } else {
        echo "<p style='color:red;'>⚠ 進級要件を満たしていません。</p>";
    }

    if ($Is_result_Research) {
        echo "<p style='color:green;'>✅ 卒研着手に問題はありません！</p>";
    } else {
        echo "<p style='color:red;'>⚠ 卒研着手要件を満たしていません。</p>";
    }

    if ($Is_result_Graduation) {
        echo "<p style='color:green;'>✅ 卒業に問題はありません！</p>";
    } else {
        echo "<p style='color:red;'>⚠ 卒業要件を満たしていません。</p>";
    }
    
}


// 進級判定関数
function keisan($myScore, &$requirement) { // 参照渡しで要件を更新.$requirementは,配列内の数字を直接いじるためにポインタで指定する.

    foreach ($myScore as $myscore) {
        if ($myscore["Grade"] >= 60) { //山形大学では60点以上で単位認定なので,60点以上の授業(単位が取得できた授業)のみカウント.
            foreach ($requirement as $reqKey => &$reqValue) { //readRequiredCreditsCSV()関数において,$requiredCredits[$linedata[0]] = (int)$linedata[1];と格納した。この$linedata[0]が$reqKeyで,この(int)$linedata[1]は$reqValueである.また、$reqValueの値を操作するのでポインタで指している.
              
                $categories = explode('+', $reqKey);        // `+` で分割してリスト化する.  csvで、いくつかの単位の合計の単位数のボーダーを求めたいときに使用する.
                
                foreach ($categories as $cat) {

                    //myScore内に必要な単位名orカテゴリが含まれているならば、reqValueからその取得した単位数だけ値を減算.
                    if (
                        (isset($myscore['CourseCategory']) && stripos($myscore['CourseCategory'], $cat) !== false) ||
                        (isset($myscore['CourseSubcategory']) && stripos($myscore['CourseSubcategory'], $cat) !== false) ||
                        (isset($myscore['CourseName']) && stripos($myscore['CourseName'], $cat) !== false)
                    ) {
                        $reqValue -= $myscore['Credits']; 
                    }
                }
            }
        }
    }
    echo "<h3>📌 判定結果</h3>";
    // 判定結果の表示
    $isOK = true;
    foreach ($requirement as $reqKey => &$reqValue) {
        if ($reqValue > 0) {
            echo "⚠ <strong>「{$reqKey}」</strong> の単位が <strong>{$reqValue} 単位</strong> 足りていません。<br>";
            $isOK = false;
        }
    }
    if($isOK)echo"問題ありません";
    return $isOK;
}


?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        function goBack() {
            window.history.back();
        }
    </script>
        <link rel="stylesheet" href="style.css">
</head>
<body>
    <button class="back-button"onclick="goBack()">前のページに戻る</button>
</body>
</html>


<?php
/* 以下ファイルが削除されたかのデバック用コード
if (file_exists($file)) {
    if (unlink($file)) {
        echo "ファイルが削除されました。";
    } else {
        echo "ファイルの削除に失敗しました。";
    }
} else {
    echo "ファイルが見つかりません。";
}*/
?> 

